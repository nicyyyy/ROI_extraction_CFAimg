Download the VOC 2007 data and put them in this directory.

This program needs OpenCV readable data. An OpenCV readable of VOC 2007 annotation could be donwload from: 
http://mmcheng.net/mftp/Data/VOC2007_AnnotationsOpenCV_Readable.7z
