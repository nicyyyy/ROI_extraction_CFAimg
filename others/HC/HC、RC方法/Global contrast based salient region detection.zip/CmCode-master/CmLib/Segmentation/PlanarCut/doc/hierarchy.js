var hierarchy =
[
    [ "CDijkNode", "a00009.html", null ],
    [ "CGEdge", "a00010.html", null ],
    [ "CGNode", "a00011.html", null ],
    [ "CGraph", "a00012.html", null ],
    [ "CutGrid", "a00013.html", [
      [ "CutSegment", "a00015.html", null ]
    ] ],
    [ "CutPlanar", "a00014.html", null ],
    [ "CutShape", "a00016.html", null ],
    [ "DijkHeap", "a00017.html", null ],
    [ "ExceptionCheckConnectivity", "a00018.html", null ],
    [ "ExceptionCheckNonNegativeCost", "a00019.html", null ],
    [ "ExceptionCheckPlanarity", "a00020.html", null ],
    [ "ExceptionSinkNotDefined", "a00021.html", null ],
    [ "ExceptionSourceNotDefined", "a00022.html", null ],
    [ "ExceptionSourceSinkIdentical", "a00023.html", null ],
    [ "ExceptionUnexpectedError", "a00024.html", null ],
    [ "PlanarEdge", "a00025.html", null ],
    [ "PlanarFace", "a00026.html", null ],
    [ "PlanarVertex", "a00027.html", null ]
];