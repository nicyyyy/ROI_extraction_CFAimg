var annotated =
[
    [ "CDijkNode", "a00009.html", "a00009" ],
    [ "CGEdge", "a00010.html", "a00010" ],
    [ "CGNode", "a00011.html", "a00011" ],
    [ "CGraph", "a00012.html", "a00012" ],
    [ "CutGrid", "a00013.html", "a00013" ],
    [ "CutPlanar", "a00014.html", "a00014" ],
    [ "CutSegment", "a00015.html", "a00015" ],
    [ "CutShape", "a00016.html", "a00016" ],
    [ "DijkHeap", "a00017.html", "a00017" ],
    [ "ExceptionCheckConnectivity", "a00018.html", null ],
    [ "ExceptionCheckNonNegativeCost", "a00019.html", null ],
    [ "ExceptionCheckPlanarity", "a00020.html", null ],
    [ "ExceptionSinkNotDefined", "a00021.html", null ],
    [ "ExceptionSourceNotDefined", "a00022.html", null ],
    [ "ExceptionSourceSinkIdentical", "a00023.html", null ],
    [ "ExceptionUnexpectedError", "a00024.html", null ],
    [ "PlanarEdge", "a00025.html", "a00025" ],
    [ "PlanarFace", "a00026.html", null ],
    [ "PlanarVertex", "a00027.html", "a00027" ]
];