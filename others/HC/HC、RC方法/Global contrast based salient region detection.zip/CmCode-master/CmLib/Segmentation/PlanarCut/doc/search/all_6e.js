var searchData=
[
  ['next',['next',['../a00010.html#acb87bc67cd5f72b8e729dceeb00c6af7',1,'CGEdge']]],
  ['node',['node',['../a00009.html#ac6a3e47af83258a118dda154d7c3403b',1,'CDijkNode']]]
];
