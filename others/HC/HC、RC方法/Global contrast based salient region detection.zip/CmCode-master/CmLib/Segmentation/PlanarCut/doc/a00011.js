var a00011 =
[
    [ "first", "a00011.html#a892fd4f5d7f89720bdcfcf9a79eadfe6", null ],
    [ "tag", "a00011.html#a9a023ede5be3c9b4ecd679cfb62d334e", null ],
    [ "type", "a00011.html#a212aac59a25700b3018d2d7d293d6489", null ],
    [ "heapId", "a00011.html#a232b512b78d8b1e1a2a650f744d016b9", null ],
    [ "dijkWeight", "a00011.html#a0c91804a761a15207b26beffad7b013f", null ],
    [ "dijkPrev", "a00011.html#a582651541a404ff5c4f1dbf74728ba9a", null ]
];