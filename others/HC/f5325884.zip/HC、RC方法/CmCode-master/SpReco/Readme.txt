This code is free for research and education use. 
Source code download address: http://mmcheng.net/imagespirit/
Please cite corresponding paper if you use it in your research, 
see the source code download adrees for latest citation informations.


Notice: this project is used to support speach recognition of my 
ImageSpirit project. See the corresponding paper for more detials.
The CORE part of ImageSpirit system will be made public avlialible 
soon.

Dependence: 
1. <sphelper.h> from 'Windows software development kit (SDK)'. 
	See http://msdn.microsoft.com/en-us/windows/hardware/bg162891.aspx 
	for lastest version
2. QT5: http://qt-project.org/downloads


Links: 
For more useful source code, please see: http://mmcheng.net/code-data/ 
