var a00010 =
[
    [ "head", "a00010.html#ac44bb9181ade43fafab135d9b502c0cc", null ],
    [ "next", "a00010.html#acb87bc67cd5f72b8e729dceeb00c6af7", null ],
    [ "sister", "a00010.html#a1a14c1ea1eef1d4ba4969f548e12fee4", null ],
    [ "weight", "a00010.html#a0447ba93f7b39f8015a5efe273868980", null ]
];