var searchData=
[
  ['edge_5fbased',['EDGE_BASED',['../a00016.html#acff797acf2ec08d0f6518751453cd8e2a09903e76363ec9eb25fd4721769b0ac5',1,'CutShape']]]
];
