var searchData=
[
  ['exceptioncheckconnectivity',['ExceptionCheckConnectivity',['../a00018.html',1,'']]],
  ['exceptionchecknonnegativecost',['ExceptionCheckNonNegativeCost',['../a00019.html',1,'']]],
  ['exceptioncheckplanarity',['ExceptionCheckPlanarity',['../a00020.html',1,'']]],
  ['exceptionsinknotdefined',['ExceptionSinkNotDefined',['../a00021.html',1,'']]],
  ['exceptionsourcenotdefined',['ExceptionSourceNotDefined',['../a00022.html',1,'']]],
  ['exceptionsourcesinkidentical',['ExceptionSourceSinkIdentical',['../a00023.html',1,'']]],
  ['exceptionunexpectederror',['ExceptionUnexpectedError',['../a00024.html',1,'']]]
];
