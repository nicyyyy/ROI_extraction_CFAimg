var examples =
[
    [ "cutgrid.cpp", "a00002.html", null ],
    [ "cutplanar.cpp", "a00001.html", null ],
    [ "cutsegment.cpp", "a00003.html", null ],
    [ "cutshape.cpp", "a00004.html", null ]
];