var searchData=
[
  ['planaredge',['PlanarEdge',['../a00025.html',1,'']]],
  ['planarface',['PlanarFace',['../a00026.html',1,'']]],
  ['planarvertex',['PlanarVertex',['../a00027.html',1,'']]]
];
